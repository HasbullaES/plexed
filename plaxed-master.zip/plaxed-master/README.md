# Plaxed
Este es el código que se usó en la primera red social de Venezuela, Plaxed.com. Fue creado por Jesus Cabrera en su totalidad.

Sientete libre de descargarlo y hacer lo que desees con el código.
