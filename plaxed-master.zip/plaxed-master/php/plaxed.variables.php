<?php
	define('PLAXED_UPLOAD_SIZE_MAX', 1048576);
	define('IMGUR_KEY', "82fe883efe8cc478881aaf50561e276a");
	define('PLAXED_REGISTRO_HABILITADO', $registroAbierto);
	define('PLAXED_SOPORTE_CORREO', "soporte@plaxed.com");
	define('PLAXED_ACTUALIZACION_TIMEOUT', 30);
?>